KOTLIN — CLASSES, OBJECTS AND INTERFACES
Fernando Lucatelli Nunes
Object-Oriented Programming · BSc Mathematics
University of Coimbra · 2026/2027

START HERE

Open index.html in a web browser. It contains the explanations, examples,
expected outputs and tables from all 94 slides, with links to complete code
files. The guide works offline. kotlin-slides-en.pdf contains the English
presentation. further-study.html develops the main ideas through further
examples, exercises and interactive illustrations.

STUDY ROUTE

  1–11  Preparation
 12–28  Classes
 29–42  Data classes
 43–50  Enum classes
 51–57  Object
 58–67  Companion object
 68–85  Interfaces
 86–94  Reference and further study

Start with preparation and classes. Continue with data classes, enumerations,
shared objects, companion objects and interfaces. Use the final reference
section to revisit a particular feature. The further study notes connect
these ideas to larger examples and project work.

RUNNING AN EXAMPLE

Open https://play.kotlinlang.org and choose Kotlin/JVM. Open one .kt file from
code/, copy its complete contents into the Playground, and run it. Compare
the output with the corresponding .out or expected-output file. Playground
execution needs an internet connection; reading the materials does not.

Run ONE independent file at a time. Different examples deliberately reuse
names such as Hora, Livro, Operacao and main. Combining independent examples
may create duplicate declarations. A slide may show only an excerpt: its
file link always points to the complete example. The modular calculator on
slides 79–82 is one program, stored in one complete .kt file.

CODE FOLDERS

code/programas/    Complete examples to run and modify.
code/exercicios/   Exercise starters with parts to complete.
code/resolucoes/   Complete solutions to the six slide exercises.
code/extension/    Further examples and solutions from the study notes.

Identifiers and file names remain consistent with the classroom examples.
English explanations, comments and user-facing messages accompany them.

EXERCISES AND SOLUTIONS

Try each exercise before reading its solution. TODO("...") marks unfinished
code: it can compile, but throws NotImplementedError when execution reaches
it. Replace TODO with the required implementation. An expected-output file
describes the result after completing the exercise, not the unfinished starter.

Slide 26 → solution 27: minutes since the start of the day.
Slide 41 → solution 42: a duration in seconds.
Slide 49 → solution 50: three possible days.
Slide 56 → solution 57: conversion with common rules.
Slide 64 → solution 65: a factory for a valid time.
Slide 76 → solution 77: a subtraction operation.

After obtaining the expected result, change the data, predict the new output
and explain why it follows. Check boundary values and invalid arguments too.
Commented lines may illustrate deliberate compilation or validation errors.
Run the unchanged example first and try each error separately.

The further study notes include additional exercises and expandable solutions.
Their interactive illustrations work offline. Links to documentation, the
Playground and the course website require an internet connection.

Course website:
https://flnlucatelli.github.io/TEACHING/OOPCOIMBRA2026/

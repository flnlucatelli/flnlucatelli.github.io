Compile PCS_2026_Book_of_Abstracts.tex twice with pdfLaTeX.
The book contains the programme and all 20 scheduled entries, including three announced placeholders.

Compile PCS_2026_Book_of_Abstracts.tex twice with pdfLaTeX.
The book contains the programme and all 18 scheduled talks, including three pending abstracts and one pending title.
The compiled book remains temporarily unpublished.
Updated 9 November 2026: Thursday ends at 17:10; talk titles supplied for Rui Prezado and Maria Manuel Clementino.
Updated 11 November 2026: Tim Van der Linden’s talk cancelled; on-site registration moved to 15:05--15:30; the first talk begins at 15:30.

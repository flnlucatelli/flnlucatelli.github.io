XVI Portuguese Category Seminar: Programme and Abstracts
Updated 15 November 2026.

Compile PCS_2026_Programme_and_Abstracts.tex three times with pdfLaTeX.
Keep pcs-logo.pdf and now-and-then-qr.png in the same directory.

Contains all 17 scheduled abstracts, including all references.
Programme times are local to Coimbra (WET / UTC+0).
QR destination: https://flnlucatelli.github.io/2026/now-next-in.html
The compiled booklet is linked from the conference website.

Thursday coffee break: 16:00–16:30. Logan Geenis: 16:30–16:50.

Saturday: group photo at 11:00, then coffee break until 11:30. Conference lunch follows the final talk at 12:30.
